# ideal-spork
Tugas DASPRO.

Aplikasi To-Do via CLI.

# Specs
- [x] Integrasi dengan SQLite
- [x] Opsi user untuk CRUD To-Do