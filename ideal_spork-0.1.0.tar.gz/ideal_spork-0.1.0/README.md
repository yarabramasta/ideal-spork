# ideal-spork
Tugas DASPRO.

Aplikasi To-Do via CLI.

# Specs
- [x] Integrasi dengan SQLite
- [x] Opsi user untuk CRUD To-Do

# Instalasi
```bash
curl -s https://raw.githubusercontent.com/yarabramasta/ideal-spork/master/bin/install | bash
```