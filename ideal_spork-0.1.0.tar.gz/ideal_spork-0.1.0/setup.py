# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ideal_spork', 'ideal_spork.data', 'ideal_spork.domain.todo']

package_data = \
{'': ['*']}

install_requires = \
['pysqlite3>=0.4.8,<0.5.0']

entry_points = \
{'console_scripts': ['ideal_spork = ideal_spork.__main__:main']}

setup_kwargs = {
    'name': 'ideal-spork',
    'version': '0.1.0',
    'description': '',
    'long_description': '# ideal-spork\nTugas DASPRO.\n\nAplikasi To-Do via CLI.\n\n# Specs\n- [x] Integrasi dengan SQLite\n- [x] Opsi user untuk CRUD To-Do',
    'author': 'yarabramasta',
    'author_email': 'yarabram111@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
